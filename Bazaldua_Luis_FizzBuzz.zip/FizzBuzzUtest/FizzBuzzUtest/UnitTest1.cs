﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FizzBuzzLibrary;

namespace FizzBuzzUtest
{
    [TestClass]
    public class UnitTest1
    {

        /// <summary>
        /// 
        /// Write 2 negative tests to establish that the valid range for the 
        /// length parameter is between 1 and 100.
        /// 
        /// </summary>
        /// 
        [TestMethod]
        public void FailsGT100()
        {
            FizzBuzz fizz = new FizzBuzz();
            try
            {
                string test = fizz.Process(101);
            }
            catch (Exception)
            {

                Assert.IsTrue(true);
            }

        }


        [TestMethod]
        public void FailsLT1()
        {
            FizzBuzz fizz = new FizzBuzz();
            try
            {
                string test = fizz.Process(0);
            }
            catch (Exception)
            {

                Assert.IsTrue(true);
            }

        }

        /// <summary>
        /// 
        /// Write 10 positive tests to establish that it returns the correct string
        /// for length parameter values 1 through 10, using the default constructor.
        /// 
        /// Default araingment
        /// 1,2,Fizz,4,Buzz,Fizz
        ///      ^      ^    ^
        /// </summary>

        #region ValidReturn 1 - 10
        [TestMethod]
        public void ValidReturn1()
        {
            FizzBuzz fizz = new FizzBuzz();
            string test = fizz.Process(1);
            Assert.AreEqual("1", test);
        }

        [TestMethod]
        public void ValidReturn2()
        {
            FizzBuzz fizz = new FizzBuzz();
            string test = fizz.Process(2);
            Assert.AreEqual("1,2", test);
        }

        [TestMethod]
        public void ValidReturn3()
        {
            FizzBuzz fizz = new FizzBuzz();
            string test = fizz.Process(3);
            Assert.AreEqual("1,2,Fizz", test);
        }

        [TestMethod]
        public void ValidReturn4()
        {
            FizzBuzz fizz = new FizzBuzz();
            string test = fizz.Process(4);
            Assert.AreEqual("1,2,Fizz,4", test);
        }

        [TestMethod]
        public void ValidReturn5()
        {
            FizzBuzz fizz = new FizzBuzz();
            string test = fizz.Process(5);
            Assert.AreEqual("1,2,Fizz,4,Buzz", test);
        }

        [TestMethod]
        public void ValidReturn6()
        {
            FizzBuzz fizz = new FizzBuzz();
            string test = fizz.Process(6);
            Assert.AreEqual("1,2,Fizz,4,Buzz,Fizz", test);
        }

        //Bug: cannot Access FizzBuzz's Process() function with parameter 7
        // due to the current state of the object 
        [TestMethod]
        public void ValidReturn7()
        {
            FizzBuzz fizz = new FizzBuzz();
            string test = fizz.Process(7);
            Assert.AreEqual("1,2,Fizz,4,Buzz,Fizz,7", test);

        }


        [TestMethod]
        public void ValidReturn8()
        {
            FizzBuzz fizz = new FizzBuzz();
            string test = fizz.Process(8);
            Assert.AreEqual("1,2,Fizz,4,Buzz,Fizz,7,8", test);
        }

        [TestMethod]
        public void ValidReturn9()
        {
            FizzBuzz fizz = new FizzBuzz();
            string test = fizz.Process(9);
            Assert.AreEqual("1,2,Fizz,4,Buzz,Fizz,7,8,Fizz", test);
        }

        [TestMethod]
        public void ValidReturn10()
        {
            FizzBuzz fizz = new FizzBuzz();
            string test = fizz.Process(10);
            Assert.AreEqual("1,2,Fizz,4,Buzz,Fizz,7,8,Fizz,Buzz", test);
        }
        #endregion

        #region ValidReturn 30 - 50 - 100

        [TestMethod]
        public void ValidReturn30()
        {
            FizzBuzz fizz = new FizzBuzz();
            string procc = fizz.Process(30);
            char[] test = procc.ToCharArray();
            char[] shouldFizz = new char[8];
            char spellingFizz;
            int counter = test.Length - 1;
            int speller = 7;
            while (true)
            {
                spellingFizz = test[counter];
                if (spellingFizz == ',')
                {
                    break;
                }
                else
                {
                    shouldFizz[speller] = spellingFizz;
                    speller--;
                    counter--;

                }

            }
            string fizzing = shouldFizz.ToString();


            Assert.Equals("FizzBuzz", fizzing);
        }

        [TestMethod]
        public void ValidReturn50()
        {
            FizzBuzz fizz = new FizzBuzz();
            string procc = fizz.Process(50);
            char[] test = procc.ToCharArray();
            char[] shouldFizz = new char[8];
            char spellingFizz;
            int counter = test.Length - 1;
            int speller = 7;
            while (true)
            {
                spellingFizz = test[counter];
                if (spellingFizz == ',')
                {
                    break;
                }
                else
                {
                    shouldFizz[speller] = spellingFizz;
                    speller--;
                    counter--;

                }

            }
            string fizzing = shouldFizz.ToString();


            Assert.Equals("Buzz", fizzing);
        }

        [TestMethod]
        public void ValidReturn100()
        {
            FizzBuzz fizz = new FizzBuzz();
            string procc = fizz.Process(100);
            char[] test = procc.ToCharArray();
            char[] shouldBuzz = new char[8];
            char spellingBuzz;
            int counter = test.Length - 1;
            int speller = 7;
            while (true)
            {
                spellingBuzz = test[counter];
                if (spellingBuzz == ',')
                {
                    break;
                }
                else
                {
                    shouldBuzz[speller] = spellingBuzz;
                    speller--;
                    counter--;

                }

            }
            string Buzzing = shouldBuzz.ToString();


            Assert.Equals("Buzz", Buzzing);
        }
        #endregion


        /// <summary>
        /// 
        ///  Bug will not place FizzBuzz o desegnated Positions in c2 & c1
        ///  Bug wont Place  on positions 6 & 12 whene creating procc in c1
        ///  Bug costum Constructor wont Create FizzBuzz in desegnated Possition in c3
        ///  
        ///  
        /// </summary>
        #region Testing Custom Constructor 
        [TestMethod]
        public void ValidReturnc1()
        {
            FizzBuzz fizz = new FizzBuzz(2, "Fuzz", 3, "Buzz");
            string procc = fizz.Process(12);
            char[] test = procc.ToCharArray();
            string shouldFizz = "";
            char spellingFizz;
            int counter = 0;
            int position = 1;
            bool switcher = false;
            bool DontFail = true;
            while (true)
            {
                if (switcher)
                {
                    if (position % 3 == 0 && position % 2 == 0)
                    {

                        if (shouldFizz != "FuzzBuzz")
                        {
                            DontFail = false;
                            break;
                        }

                    }
                    else if (position % 3 == 0)
                    {
                        if (shouldFizz != "Buzz")
                        {
                            DontFail = false;
                            break;
                        }
                    }
                    else if (position % 2 == 0)
                    {
                        if (shouldFizz != "Fuzz")
                        {
                            DontFail = false;
                            break;
                        }
                    }
                    switcher = false;
                    shouldFizz = "";
                    position++;

                }
                if (position >= 12)
                {
                    break;
                }
                spellingFizz = test[counter];
                if (spellingFizz == ',')
                {
                    switcher = true;
                    counter++;
                }
                else if (spellingFizz != '\0')
                {
                    shouldFizz = shouldFizz + spellingFizz;
                    counter++;

                }
                if (position >= 12)
                {
                    break;
                }

            }
            Assert.IsTrue(DontFail);




        }
        [TestMethod]
        public void ValidReturnc2()
        {
            FizzBuzz fizz = new FizzBuzz(6, "Fuzz", 2, "Buzz");
            string procc = fizz.Process(15);
            char[] test = procc.ToCharArray();
            string shouldFizz = "";
            char spellingFizz;
            int counter = 0;
            int position = 1;
            bool switcher = false;
            bool DontFail = true;
            while (true)
            {
                if (switcher)
                {
                    if (position % 6 == 0 && position % 2 == 0)
                    {

                        if (shouldFizz != "FuzzBuzz")
                        {
                            DontFail = false;
                            break;
                        }

                    }
                    else if (position % 2 == 0)
                    {
                        if (shouldFizz != "Buzz")
                        {
                            DontFail = false;
                            break;
                        }
                    }
                    else if (position % 6 == 0)
                    {
                        if (shouldFizz != "Fuzz")
                        {
                            DontFail = false;
                            break;
                        }
                    }
                    switcher = false;
                    shouldFizz = "";
                    position++;

                }
                if (position >= 15)
                {
                    break;
                }
                spellingFizz = test[counter];
                if (spellingFizz == ',')
                {
                    switcher = true;
                    counter++;
                }
                else if (spellingFizz != '\0')
                {
                    shouldFizz = shouldFizz + spellingFizz;
                    counter++;

                }
                

            }
            Assert.IsTrue(DontFail);




        }
        [TestMethod]
        public void ValidReturnc3()
        {
            FizzBuzz fizz = new FizzBuzz(5, "Fuzz", 3, "Buzz");
            string procc = fizz.Process(15);
            char[] test = procc.ToCharArray();
            string shouldFizz = "";
            char spellingFizz;
            int counter = 0;
            int position = 1;
            bool switcher = false;
            bool DontFail = true;
            while (true)
            {
                if (switcher)
                {
                    if (position % 5 == 0 && position % 3 == 0)
                    {

                        if (shouldFizz != "FuzzBuzz")
                        {
                            DontFail = false;
                            break;
                        }

                    }
                    else if (position % 3 == 0)
                    {
                        if (shouldFizz != "Buzz")
                        {
                            DontFail = false;
                            break;
                        }
                    }
                    else if (position % 5 == 0)
                    {
                        if (shouldFizz != "Fuzz")
                        {
                            DontFail = false;
                            break;
                        }
                    }
                    switcher = false;
                    shouldFizz = "";
                    position++;

                }
                if (position >= 15)
                {
                    break;
                }
                spellingFizz = test[counter];
                if (spellingFizz == ',')
                {
                    switcher = true;
                    counter++;
                }
                else if (spellingFizz != '\0')
                {
                    shouldFizz = shouldFizz + spellingFizz;
                    counter++;

                }
                

            }
            Assert.IsTrue(DontFail);




        }
        #endregion      // bug will not place FizzBuzz o desegnated Positions in this case 6 & 12




    }
}
