﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDLab;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDLab.Tests
{
    [TestClass()]
    public class StringCalTests
    {
     

        [TestMethod]
        public void AddInputTestnullorempty()
        {
            StringCal cal = new StringCal();
            Assert.AreEqual(cal.Add(""), "0");

        }

        [TestMethod]
        public void AddInputTest1num()
        {
            StringCal cal = new StringCal();
            Assert.AreEqual(cal.Add("1"),"1");
        }

        [TestMethod]
        public void AddInputTestC()
        {
            StringCal cal = new StringCal();
            Assert.AreEqual(cal.Add("1,1"), "2");
        }        
        
        [TestMethod]
        public void AddInputTestD()
        {
            StringCal cal = new StringCal();
            Assert.AreEqual(cal.Add("1\n1"), "1");
        }

        [TestMethod]
        public void AddInputTestE()
        {
            StringCal cal = new StringCal();
            Assert.AreEqual(cal.Add("//*\n1*2"), "3");
        }

        [TestMethod]
        public void AddInputTestF()
        {
            string txt = "";
            StringCal cal = new StringCal();
            try
            {
                txt  = cal.Add("-1,-1");
            }
            catch (ArgumentException e)
            {

                Assert.IsTrue(true,(e.Message));
            }
        }

        [TestMethod]
        public void AddInputTestG()
        {
            StringCal cal = new StringCal();
            Assert.AreEqual(cal.Add("1001,2"), "2");
        }

        [TestMethod]
        public void AddInputTestH()
        {
            StringCal cal = new StringCal();
            Assert.AreEqual(cal.Add("//[--][%]\n1000--2"), "1002");
        }

        [TestMethod]
        public void AddInputTestI()
        {
            StringCal cal = new StringCal();
            Assert.AreEqual(cal.Add("//[---]\n1000---2"), "1002");
        }


    }
}