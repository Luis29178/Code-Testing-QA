﻿namespace TDDLab
{
    public class StringCal
    {
        private string[] delimiter;
        private string numString;
        private string stringSum;
        private int intSum;
        private int startIndex;
        private bool foundNegatives = false;

        public string Add(string _numString)
        {
            numString = _numString;


            if (numString == "" || numString == null)
            {
                return "0";
            }

            SetDelim();

            StingFuncToIntSum();





            return stringSum;
        }

        private void StingFuncToIntSum()
        {
            int i = startIndex;
            int sum = 0;
            string tempNum = "";
            int DelimiterIndex = 0;
            string negatives = "";
            bool NotNeg = true;

            if (numString[i] == '\n')
            {
                i++;
            }

            while (i <= numString.Length)
            {
                string deli = delimiter[DelimiterIndex];
                
                #region Sum&limitCHeck
                if (tempNum != "" && Int32.Parse(tempNum) <= 1000 )
                {
                    sum += Int32.Parse(tempNum);
                }

                if (i >= numString.Length)
                {
                   
                    break;
                }
                #endregion
                //will Skip when not Delimiter
                #region DelimiterCHeck
                if (i < numString.Length && numString[i] == deli[0] )
                {
                    

                    foreach (char currdelichar in deli)
                    {
                        if (numString[i] != currdelichar)
                        {
                            throw new ArgumentException("Incorrect Delimiter");
                        }
                        else
                        {
                            i++;
                        }
                    }


                    #region DelimiterSwitcher
                    if (DelimiterIndex >= (delimiter.Length - 1))
                    {
                        DelimiterIndex = 0;
                    }
                    else
                    {
                        DelimiterIndex++;
                    }
                    #endregion

                    tempNum = "";
                }
                #endregion
                
                

                while ( i < numString.Length && numString[i] != deli[0])
                {

                    if (numString[i] != '-' && NotNeg)
                    {
                        tempNum += numString[i];
                        i++; 
                    }
                    else
                    {
                        foundNegatives = true;
                        NotNeg = false;
                        break;
                    }
                }

                while (i < numString.Length && numString[i] != deli[0] && !NotNeg)
                {
                    tempNum += numString[i];
                    i++;
                }

                if (!NotNeg)
                {
                    negatives += (" | " + tempNum);
                    NotNeg = true;
                }
                


            }
            
            if (foundNegatives)
            {
                throw new ArgumentException("Negatives not Allowed" + negatives);
            }
            else
            {
                intSum = sum;
                stringSum = sum.ToString();
            }




        }
        private void SetDelim()
        {
            int i = 0;
            int stringlngthref = numString.Length - 1;
            char currChar = numString[i];
            int delCount;
            
            if (delimiter == null)
            {
                delCount = 0;
            }
            else
            { 
                delCount =( delimiter.Length + 1);
            }

            while (i < stringlngthref && numString[i] != '\n')
            {
                i++;
            }

            if (i == stringlngthref)
            {
                i = 0;
            }
            
            
            if (i <= stringlngthref)
            {
                startIndex = i;
                while (i > 0 && numString[i] != '/' )
                {
                    i--;
                }
            }
            

            
            if (numString[i] != '/')
            {
                i++;
                delimiter = new string[1];
                delimiter[0] = ",";
                return;
            }
            i++;
            string temdel = "";
            while (numString[i] != '\n')
            {
                if (numString[i] == '[')
                {
                    i++;
                    temdel = "";
                    while (numString[i] != ']')
                    {
                        temdel += numString[i];
                        i++;
                    }

                    
                    string[] tempdelarr = new string[delCount+1];
                    if (delCount != 0)
                    {
                        int x = 0;
                        foreach (string deli in delimiter)
                        {
                            tempdelarr[x] = deli;
                            x++;
                        }

                        tempdelarr[x] = temdel;
                        delimiter = tempdelarr;
                    }
                    else
                    {
                        tempdelarr = new string[1];
                        tempdelarr[0] = temdel;
                        delimiter = tempdelarr;
                        delCount++;
                    }


                }
                else
                {
                    temdel = "";
                    while (numString[i] != '[' && numString[i] !='\n')
                    {
                        temdel += numString[i];
                        i++;
                    }

                } 
            }

            if (delimiter == null)
            {
                string[] tempdelarr = new string[1];
                tempdelarr[0] = temdel;
                delimiter = tempdelarr;
            }
        }
    }

}