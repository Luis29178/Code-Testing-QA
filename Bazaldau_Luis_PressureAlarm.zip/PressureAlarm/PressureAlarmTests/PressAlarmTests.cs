﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PressureAlarm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using PressureAlarm;
using PressureAlarmTests;

namespace PressureAlarm.Tests
{
    [TestClass()]
    public class PressAlarmTests
    {
         [TestMethod()]
        public void TestHi()
        {
            MYOSensor sensor = new MYOSensor();
            sensor.pressure = 44;
            PressAlarm alarm = new PressAlarm(sensor);

            alarm.Check();

            Assert.IsTrue(alarm.Alarm);
        }

        [TestMethod()]
        public void TestMid()
        {
            MYOSensor sensor = new MYOSensor();
            sensor.pressure = 28;
            PressAlarm alarm = new PressAlarm(sensor);

            alarm.Check();

            Assert.IsFalse(alarm.Alarm);
        }

        [TestMethod()]
        public void TestLow()
        {
            MYOSensor sensor = new MYOSensor();
            sensor.pressure = 5;
            PressAlarm alarm = new PressAlarm(sensor);

            alarm.Check();

            Assert.IsTrue(alarm.Alarm);
        }


        [TestMethod()]
        public void MoqTestHi()
        {
            Mock<ISensor> mock = new Mock<ISensor>();
            mock.Setup(x => x.QueryHardwareForPsiValue()).Returns(44);
            PressAlarm alarm = new PressAlarm(mock.Object);

            alarm.Check();

            Assert.IsTrue(alarm.Alarm);
        }

        [TestMethod()]
        public void MoqTestMid()
        {
            Mock<ISensor> mock = new Mock<ISensor>();
            mock.Setup(x => x.QueryHardwareForPsiValue()).Returns(28);
            PressAlarm alarm = new PressAlarm(mock.Object);

            alarm.Check();

            Assert.IsFalse(alarm.Alarm);
        }

        [TestMethod()]
        public void MoqTestLow()
        {
            Mock<ISensor> mock = new Mock<ISensor>();
            mock.Setup(x => x.QueryHardwareForPsiValue()).Returns(5);
            PressAlarm alarm = new PressAlarm(mock.Object);

            alarm.Check();

            Assert.IsTrue(alarm.Alarm);
        }
    }
}